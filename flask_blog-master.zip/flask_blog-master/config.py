# 数据库配置
SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@localhost:3306/flaskblog'
SQLALCHEMY_TRACK_MODIFICATIONS = True
SQLALCHEMY_ECHO = True

# 上传图片配置
MAX_CONTENT_LENGTH = 1 * 1024 * 1024

